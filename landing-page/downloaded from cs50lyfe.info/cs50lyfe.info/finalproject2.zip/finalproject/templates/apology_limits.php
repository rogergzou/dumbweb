<p>
    Sorry!
</p>
<p>
    <?= htmlspecialchars($message) ?>
</p>

<a href="limits.php">Back</a>
