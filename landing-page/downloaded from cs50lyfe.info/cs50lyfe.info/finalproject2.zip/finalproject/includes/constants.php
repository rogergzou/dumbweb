<?php

    /**
     * constants.php
     *
     * Computer Science 50
     * Problem Set 7
     *
     * Global constants.
     */

    // your database's name
    define("DATABASE", "rzou_dreading_cs50_finalproject");

    // your database's password
    define("PASSWORD", "dingdingditch");

    // your database's server
    define("SERVER", "rzou-dreading-cs50-finalproject.cs50lyfe.info");

    // your database's username
    define("USERNAME", "therogerzou");

?>
