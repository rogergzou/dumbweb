<p>
    Sorry!
</p>
<p>
    <?= htmlspecialchars($message) ?>
</p>

<a href="expenses.php">Back</a>
