<form action="register.php" method="post">
    <fieldset>
        <div>
            <input autofocus name="user" placeholder="Username" type="text"/>
        </div>
        <div>
            <input name="password" placeholder="Password" type="password"/>
        </div>
        <div>
            <input name="confirmation" placeholder="Confirm password" type="password"/>
        </div>
        <div>
            <button type="submit">Register</button>
        </div>
    </fieldset>
</form>
<div>
    or <a href="login.php">log in</a>
</div>
