<form action="verify.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus name="code" placeholder="000" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Verify</button>
        </div>
    </fieldset>
</form>
