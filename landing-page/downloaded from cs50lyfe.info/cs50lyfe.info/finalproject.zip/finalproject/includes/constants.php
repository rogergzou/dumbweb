<?php

    /**
     * constants.php
     *
     * David Reading and Roger Zou for CS50
     * Final Project: Save
     *
     * Global constants.
     */

    // your database's name
    define("DATABASE", "rzou_dreading_cs50_finalproject2");

    // your database's password
    define("PASSWORD", "dingdingditch");

    // your database's server
    //define("SERVER", "rzou-dreading-cs50-finalproject2.cs50lyfe.info");
	define("SERVER", "mysqlrzou-dreading-cs50-finalproject2.cs50lyfe.info");

    // your database's username
    define("USERNAME", "therogerzou");

?>
